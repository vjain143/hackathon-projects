package types

// OrderResponseRiskScore Details of a risk assessment of an order
type OrderResponseRiskScore struct {
	Value string `json:"value"`
}
