package psp_tests

import (
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestGetToken(t *testing.T) {

	assert.Equal(t, true, true, "Should be equal.")
}

func TestMakePayment(t *testing.T) {

}
