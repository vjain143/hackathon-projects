package devclienttypes

const ErrorDeviceNotInitialised = "Error: Device not initialised"
const ErrorDeviceProfileNotLoaded = "Error: Device profile not loaded"
const ErrorInvalidMenuSelection = "Error: Invalid menu selection - please choose another item"
